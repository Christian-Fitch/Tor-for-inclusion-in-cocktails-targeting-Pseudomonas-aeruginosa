setwd("C:/Users/cf466/OneDrive - University of Exeter/Documents/Documents - CF laptop/PhD/Phage Cocktails/272-950 work/Dictionaries for synograms")
dictionary <- read.csv("Dictionary.csv")
plate_contents <- read.csv("PLateContents.csv")
poly_dict <- read.csv("PolyamineDictionary.csv")

#Panel A and B are the synograms
setwd("C:/Users/cf466/OneDrive - University of Exeter/Documents/Documents - CF laptop/PhD/Phage Cocktails/272-950 work/Synograms and polyamines 9.12.24")


#This function will reformat an individual .CSV into the correct format by modifying the columns, reformatting the time
#adding in the dictionary that tells us what is in each well, and removes NAs for dodgy values
reformat <- function(df_test) {
  df_test <- df_test %>% select(-X)
  df_test[1,1] <- "Well"
  names(df_test) <- lapply(df_test[1, ], as.character)
  df_test <- df_test[-1,] 
  df_test <- pivot_longer(df_test, cols = -Well, names_to = "Time_Hours", values_to = "values") %>%
    filter(Time_Hours != "Time")
  df_test$Time_seconds <- sapply(df_test$Time_Hours, function(x) {
    # Extract hours and minutes using regular expressions
    hours <- as.numeric(sub(".*?(\\d+) h.*", "\\1", x))  # Extract hours
    minutes <- as.numeric(sub(".*?(\\d+) min.*", "\\1", x))  # Extract minutes
    
    # # Replace NA with 0 where no match found
    hours[is.na(hours)] <- 0
    minutes[is.na(minutes)] <- 0
    
    # Convert to seconds
    total_seconds <- (hours * 3600) + (minutes * 60)
    return(total_seconds)
  })
  df_test <- left_join(df_test, dictionary)
  df_test <- df_test %>% na.omit()
}

#This function now will take each of the filenames in the folder, and for each it'll take in
#the file name, run the reformatting function above, add in a column with the plate name
#(taken from the file name) 

produce_df <- function(file_name){
  df <- read.csv(file_name, header = TRUE, row.names = NULL)
  df <- reformat(df)
  file_base_name <- sub("\\.\\w+$", "", basename(file_name))
  df$plate <- file_base_name
  return(df)
}

#get the list of all the csv files in the folder
csv_files <- list.files(pattern = "\\.CSV$")

#use purrr::map_df to apply the produce_df function to each CSV file and bind them together
df_all <- map(csv_files, produce_df)

#df in list form, this isnt ideal, need a concatenated one
df_list <- function(df_list){
  final_df <- Reduce(full_join, df_list)
  return(final_df)
}
df_all <- df_list(df_all)

#now got to left join what is in what plate. As first only doing synograms, 
#will remove plates 16-18

df_all <- left_join(df_all, plate_contents)
df_polyamine <- filter(df_all, Test == "LB"|Test == "Spermine"|Test == "Spermidine")
df_all <- filter(df_all, Test != "LB"&Test != "Spermine"&Test != "Spermidine")

#now to fix some mistakes that I made in the experiment
#1 - plate 6 had cols 9 and 10 wrong way - so wrong abx conc

df_all <- df_all %>%
  mutate(Antibiotic = ifelse(plate == "Plate6" & Column == 9, 32, 
                             ifelse(plate == "Plate6" & Column == 10, 16, Antibiotic)))

#2 - plates 11 and 12 got 5 and 6 wrong way, so wrong abx conc

df_all <- df_all %>%
  mutate(Antibiotic = ifelse(plate == "Plate11" & Column == 5, 2, 
                             ifelse(plate == "Plate11" & Column == 6, 1, Antibiotic)))
df_all <- df_all %>%
  mutate(Antibiotic = ifelse(plate == "Plate12" & Column == 5, 2, 
                             ifelse(plate == "Plate12" & Column == 6, 1, Antibiotic)))

#Now the fun bit of plotting!!!
#Apparently values are characters
df_all <- df_all %>%
  mutate(values = as.numeric(values))

#First we will work out the blank df
df_blks <- df_all %>% 
  filter(Content == "BLK") %>%
  select(plate, Time_seconds, values) %>%
  group_by(plate, Time_seconds) %>%
  reframe(mean_blk_od = mean(values))

#now to normalise each datapoint
df_all <- df_all %>%
  left_join(df_blks) %>%
  mutate(norm_od = values - mean_blk_od)

#now to make the two plots, the first reduction at 24 h!
df_final_timepoint <- df_all %>%
  filter(Time_seconds == 86400)

df_final_timepoint_controls <- df_final_timepoint %>%
  filter(Well == "B02") %>%
  select(plate, norm_od) %>%
  rename(cntrl_od = norm_od)

df_final_timepoint <- df_final_timepoint %>%
  left_join(df_final_timepoint_controls) %>%
  mutate(norm_od = ifelse(norm_od < 0, 0, norm_od)) %>%
  mutate(end_red_perc = ((cntrl_od-norm_od)/cntrl_od)*100) %>%
  group_by(Test, Antibiotic, Phage) %>%
  reframe(Mean_Red_Perc = mean(end_red_perc)) %>%
  unique()

endpoint <- ggplot(df_final_timepoint, aes(x = factor(log10(Phage)), y = factor(Antibiotic), fill = Mean_Red_Perc)) +
  geom_tile() +
  scale_x_discrete("Log 10 Phage Titre (PFU/mL)", labels = c(0,2,3,4,5,6)) +
  scale_y_discrete("Antibiotic Concentration \u03BCg/mL") +
  facet_wrap(~Test, nrow = 3) +
  scale_fill_gradient2("Mean\nReduction\nPercentage", high = "white", low = "darkorange", midpoint = 100) +
  theme_cowplot(14)


#now the second plot, virulence index
df_virulence <- df_all %>%
  group_by(Well, plate, Antibiotic, Phage, Test) %>%
  reframe(area = AUC(Time_seconds, norm_od, method = "trapezoid")) %>%
  unique()

df_virulence_controls <- df_virulence %>%
  filter(Well == "B02") %>%
  select(plate, area) %>%
  rename(cntrl_area = area)

#set things to 0 too if AUC is below 0 - this isnt hugely useful for plotting
df_virulence <- df_virulence %>%
  left_join(df_virulence_controls) %>%
  mutate(vp = 1 - (area/cntrl_area)) %>%
  group_by(Well, Test) %>%
  reframe(Antibiotic = Antibiotic, plate = plate, Phage = Phage, Test = Test, mean_vp = mean(vp), stdev = sd(vp)) %>%
  unique()

virulence <- ggplot(df_virulence, aes(x = factor(Phage), y = factor(Antibiotic), fill = mean_vp)) +
  geom_tile() +
  scale_x_discrete("Log 10 Phage Titre (PFU/mL)", labels = c(0,2,3,4,5,6)) +
  scale_y_discrete("Antibiotic Concentration \u03BCg/mL") +
  facet_wrap(~Test, nrow = 3) +
  scale_fill_gradient2("Mean\nPhage\nVirulence", high = "white", low = "darkgreen", midpoint = 0.8) +
  theme_cowplot(14)

PAS <- plot_grid(endpoint, virulence, nrow = 1, labels = "AUTO")

#----------
###STATS###
#----------

#stats
#null = no difference in P272 virulence as a function of phage titre interacting with antibiotic concentration.
#alternative = difference in P272 virulence as a function of phage titre interacting with antibiotic concentration, indicating synergy or antagonism.
#threshold alpha = 0.05
#initial test = simple linear regression of format virulence~abx_conc*272_titre. As there are 0s and I need to use logs to make concentrations linear, will add a very small value to each titre so that there arent infinite values. 

df_virulence2 <- df_all %>%
 group_by(Well, plate, Antibiotic, Phage, Test) %>%
 reframe(area = AUC(Time_seconds, norm_od, method = "trapezoid")) %>%
 unique()
#
df_virulence_controls2 <- df_virulence2 %>%
 filter(Well == "B02") %>%
 select(plate, area) %>%
 rename(cntrl_area = area)
#
# #set things to 0 too if AUC is below 0 - this isnt hugely useful for plotting
df_virulence2 <- df_virulence2 %>%
 left_join(df_virulence_controls2) %>%
 mutate(vp = 1 - (area/cntrl_area))
#
tobramycin_stats <- df_virulence2 %>%
 filter(Test == "Tobramycin")
#
meropenem_stats <- df_virulence2 %>%
 filter(Test == "Meropenem")
#
colistin_stats <- df_virulence2 %>%
 filter(Test == "Colistin")
#
model_tobi <- lm(vp ~ log2(Antibiotic+0.0000000001)*log10(Phage+0.0000000001), data = tobramycin_stats)
summary(model_tobi)
plot(model_tobi)

#tobramycin significant for AB, significant for phage, not significant interaction


model_mero <- lm(vp ~ log2(Antibiotic+0.000000001)*log10(Phage+0.0000000001), data = meropenem_stats)
summary(model_mero)
plot(model_mero)

# #meropenem significant for AB, significant for phage, and a significant interaction (p = 0.00633)

#
model_col <- lm(vp ~ log2(Antibiotic+0.0000000001)*log10(Phage+0.0000000001), data = colistin_stats)
summary(model_col)
plot(model_col)

# #col significant for AB, significant for phage, not significant interaction

